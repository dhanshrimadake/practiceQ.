package org.example.PenUtils;

import org.example.entities.Pen;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public interface PopulateUtil {
    static List<Pen> generateDummyData(){
        List<Pen> pens = new ArrayList<>();
        pens.add(new Pen("BrandA", "Blue", "Blue", "Plastic", 100, LocalDate.now().minusMonths(1), LocalDate.now(), 1.5, 0.0));
        pens.add(new Pen("BrandB", "Red", "Red", "Metal", 50, LocalDate.now().minusMonths(2), LocalDate.now(), 2.0, 0.0));
        pens.add(new Pen("BrandC", "Black", "Black", "Plastic", 80, LocalDate.now().minusMonths(3), LocalDate.now(), 1.0, 0.0));
        pens.add(new Pen("BrandD", "Green", "Green", "Plastic", 120, LocalDate.now().minusMonths(4), LocalDate.now(), 1.8, 0.0));
        pens.add(new Pen("BrandE", "Purple", "Purple", "Metal", 90, LocalDate.now().minusMonths(5), LocalDate.now(), 2.5, 0.0));
        pens.add(new Pen("BrandF", "Orange", "Orange", "Plastic", 60, LocalDate.now().minusMonths(6), LocalDate.now(), 1.2, 0.0));

        // Dummy data with stockUpdateDate more than 3 months ago
        pens.add(new Pen("BrandG", "Yellow", "Yellow", "Metal", 70, LocalDate.now().minusMonths(4).minusDays(1), LocalDate.now(), 2.2, 0.0));
        pens.add(new Pen("BrandH", "White", "White", "Plastic", 40, LocalDate.now().minusMonths(4).minusDays(2), LocalDate.now(), 1.3, 0.0));
        pens.add(new Pen("BrandI", "Brown", "Brown", "Metal", 110, LocalDate.now().minusMonths(4).minusDays(3), LocalDate.now(), 2.3, 0.0));

        // Dummy data with stockUpdateDate more than 9 months ago
        pens.add(new Pen("BrandJ", "Gray", "Gray", "Plastic", 85, LocalDate.now().minusMonths(10), LocalDate.now(), 1.7, 0.0));
        pens.add(new Pen("BrandK", "Cyan", "Cyan", "Metal", 55, LocalDate.now().minusMonths(11), LocalDate.now(), 2.7, 0.0));
        pens.add(new Pen("BrandL", "Magenta", "Magenta", "Plastic", 95, LocalDate.now().minusMonths(12), LocalDate.now(), 1.9, 0.0));
        pens.add(new Pen("BrandM", "Silver", "Silver", "Metal", 75, LocalDate.now().minusMonths(13), LocalDate.now(), 2.8, 0.0));
        pens.add(new Pen("BrandN", "Gold", "Gold", "Plastic", 65, LocalDate.now().minusMonths(14), LocalDate.now(), 1.4, 0.0));

        return pens;
    }
}
