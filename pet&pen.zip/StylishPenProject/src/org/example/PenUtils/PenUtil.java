package org.example.PenUtils;

import org.example.entities.Pen;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

public interface PenUtil {
    static void addPen(List<Pen> list, String brandName, String color, String inkColor, String material, String date, int stock, double price) {
        Pen pen = new Pen(brandName, color, inkColor, material, LocalDate.parse(date), stock, price);
        list.add(pen);
    }

    static void updatePen(List<Pen> list, String brandName, String color, String inkColor, String material, int stock) {
        //first find pen with brandName and update with new color, inkColor, material, stock
        for(Pen p: list){
            if(p.getBrandName().equals(brandName)){
                if(!color.isEmpty()) p.setColor(color);
                if(!inkColor.isEmpty()) p.setInkColor(inkColor);
                if(!material.isEmpty()) p.setMaterial(material);
                p.setStock(stock);
                p.setStockUpdateDate(LocalDate.now());
            }
        }
        System.out.println("No pen found with inputted brand name");
    }

    static void setClearanceDiscount(List<Pen> totalStock){
        for(Pen p: totalStock){
            long months = p.getStockUpdateDate().until(LocalDate.now(), ChronoUnit.MONTHS);
            if(months>3){
                p.setDiscountPercent(20.0);
            }
        }
    }

    static void removeUnsoldPens(List<Pen> totalStock){
        for(int i=totalStock.size()-1;i>=0;i--){
            Pen p = totalStock.get(i);
            long months = p.getStockUpdateDate().until(LocalDate.now(),ChronoUnit.MONTHS);
            if(months>9){
                totalStock.remove(i);
            }
        }
    }

    static void displayStock(List<Pen> pens){
        for(Pen p: pens){
            System.out.println(p);
        }
    }

    static List<Pen> sortStockBasedOnUpdateDate(List<Pen> pens){
        pens = pens.stream()
                .sorted((p1,p2)-> p2.getStockUpdateDate().compareTo(p1.getStockUpdateDate()))
                .collect(Collectors.toList());
        return pens;
    }
}
