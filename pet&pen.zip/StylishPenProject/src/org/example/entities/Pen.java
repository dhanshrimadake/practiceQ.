package org.example.entities;

import java.time.LocalDate;
import java.util.UUID;

public class Pen {
    private UUID id;
    private String brandName;
    private String color;
    private String inkColor;
    private String material;
    private int stock;
    private LocalDate stockUpdateDate;   //changes when admin changes it or sale is made
    private LocalDate stockListingDate;
    private double price;
    private double discountPercent;

    public Pen(String brandName, String color, String inkColor, String material, LocalDate stockListingDate, int stock, double price) {
        this.id = UUID.randomUUID();
        this.brandName = brandName;
        this.color = color;
        this.inkColor = inkColor;
        this.material = material;
        this.stock = stock;
        this.stockListingDate = stockListingDate;
        this.stockUpdateDate = stockListingDate;
        this.price = (1-discountPercent/100)*price;
        this.discountPercent = 0.0;
    }

    public Pen(String brandName, String color, String inkColor, String material, int stock, LocalDate stockUpdateDate, LocalDate stockListingDate, double price, double discountPercent) {
        this.id = UUID.randomUUID();
        this.brandName = brandName;
        this.color = color;
        this.inkColor = inkColor;
        this.material = material;
        this.stock = stock;
        this.stockUpdateDate = stockUpdateDate;
        this.stockListingDate = stockListingDate;
        this.price = price;
        this.discountPercent = discountPercent;
    }

    public UUID getId() {
        return id;
    }

    public String getBrandName() {
        return brandName;
    }

    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getInkColor() {
        return inkColor;
    }

    public void setInkColor(String inkColor) {
        this.inkColor = inkColor;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public LocalDate getStockUpdateDate() {
        return stockUpdateDate;
    }

    public void setStockUpdateDate(LocalDate stockUpdateDate) {
        this.stockUpdateDate = stockUpdateDate;
    }

    public LocalDate getStockListingDate() {
        return stockListingDate;
    }

    public void setStockListingDate(LocalDate stockListingDate) {
        this.stockListingDate = stockListingDate;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getDiscountPercent() {
        return discountPercent;
    }

    public void setDiscountPercent(double discountPercent) {
        this.discountPercent = discountPercent;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Pen{");
        sb.append("id=").append(id);
        sb.append(", brandName='").append(brandName).append('\'');
        sb.append(", color='").append(color).append('\'');
        sb.append(", inkColor='").append(inkColor).append('\'');
        sb.append(", material='").append(material).append('\'');
        sb.append(", stock=").append(stock);
        sb.append(", stockUpdateDate=").append(stockUpdateDate);
        sb.append(", stockListingDate=").append(stockListingDate);
        sb.append(", price=").append(price);
        sb.append(", discountPercent=").append(discountPercent);
        sb.append('}');
        return sb.toString();
    }
}
