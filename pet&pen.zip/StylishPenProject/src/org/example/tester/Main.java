package org.example.tester;

import org.example.entities.Pen;

import java.util.List;
import java.util.Scanner;

import static org.example.PenUtils.PopulateUtil.generateDummyData;
import static org.example.PenUtils.PenUtil.*;

public class Main {
    public static void main(String[] args) {
        List<Pen> pens = generateDummyData();
        try(Scanner sc = new Scanner(System.in)){
            while(true){
                displayMenu();
                switch (sc.nextInt()){
                    case 1:
                        sc.nextLine();
                        System.out.println("Enter brand name:");
                        String brand = sc.nextLine();
                        System.out.println("Enter color: ");
                        String color = sc.next();
                        System.out.println("Enter ink color: ");
                        String inkColor = sc.next();
                        System.out.println("Enter material: ");
                        String material = sc.next();
                        System.out.println("Enter stock listing date (YYYY-MM-DD): ");
                        String date = sc.next();
                        System.out.println("Enter stock: ");
                        int stock = sc.nextInt();
                        System.out.println("Enter price: ");
                        double price = sc.nextDouble();

                        addPen(pens,brand,color,inkColor,material,date,stock,price);
                        break;
                    case 2:
                        sc.nextLine();
                        System.out.println("Enter brand name (mandatory):");
                        brand = sc.nextLine();
                        System.out.println("Enter color: ");
                        color = sc.next();
                        System.out.println("Enter ink color: ");
                        inkColor = sc.next();
                        System.out.println("Enter material: ");
                        material = sc.next();
                        System.out.println("Enter stock (mandatory): ");
                        stock = sc.nextInt();
                        updatePen(pens,brand,color,inkColor,material,stock);
                        break;
                    case 3:
                        setClearanceDiscount(pens);
                        break;
                    case 4:
                        removeUnsoldPens(pens);
                        break;
                    case 5:
                        displayStock(pens);
                        break;
                    case 6:
                        pens = sortStockBasedOnUpdateDate(pens);
                        break;
                    case 7:
                        System.out.println("Choosing to exit, bye!");
                        System.exit(0);
                    default:
                        System.out.println("Invalid choice");
                }
            }
        }
    }

    private static void displayMenu(){
        System.out.println("--Pen management interface menu--");
        System.out.println("1. Add new pen");
        System.out.println("2. Update a pen");
        System.out.println("3. Declare discount for clearance sale");
        System.out.println("4. Remove unsold stock");
        System.out.println("5. Display stock");
        System.out.println("6. Sort stock based on most recent stock update date");
        System.out.println("7. Exit");
    }
}