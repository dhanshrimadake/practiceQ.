package org.example.utils;

import org.example.entities.*;
import org.example.exceptions.*;

import java.util.List;

public final class UserUtil {

    private UserUtil() {
        // Prevent instantiation
    }

    public static User login(List<User> list, String email, String password) throws AuthenticationException {
        for (User u : list) {
            if (u.getEmail().equalsIgnoreCase(email)) {
                if (u.getPassword().equals(password)) {
                    return u;
                }
            }
        }
        throw new AuthenticationException("Invalid credentials");
    }

    public static void addPet(User user, List<Pet> list, Pet pet) throws AuthorizationException {
        if (user != null && user.getType() == UserType.ADMIN) {
            list.add(pet);
        } else {
            throw new AuthorizationException("Only admins can add pets");
        }
    }

    public static void updatePetDetails(User user, List<Pet> list, String petId, int stock) throws AuthorizationException {
        if (user != null && user.getType() == UserType.ADMIN) {
            boolean petFound = false;
            for (Pet p : list) {
                if (p.getPetId().toString().equals(petId)) {
                    p.setStock(stock);
                    petFound = true;
                    break;
                }
            }
            if (!petFound) {
                throw new AuthorizationException("Pet not found");
            }
        } else {
            throw new AuthorizationException("Only admins can update pet details");
        }
    }

    public static void displayAllPets(User user, List<Pet> list) throws AuthenticationException {
        if (user != null) {
            if (!list.isEmpty()) {
                for (Pet p : list) {
                    System.out.println(p);
                }
            } else {
                System.out.println("Sorry, we do not have any pets for sale at the moment");
            }
        } else {
            throw new AuthenticationException("Please login first");
        }
    }

    public static void orderPet(User user, List<Pet> list, String petId, int quantity) throws AuthenticationException, OutOfStockException {
        Pet selectedPet = null;
        for (Pet p : list) {
            if (p.getPetId().toString().equals(petId)) {
                selectedPet = p;
                break;
            }
        }

        if (selectedPet == null) {
            throw new OutOfStockException("Pet not found");
        }

        if (selectedPet.getStock() < quantity) {
            throw new OutOfStockException("Sorry, pet is out of stock");
        }

        Order order = new Order(user, selectedPet, quantity);
        user.addOrder(order);
        selectedPet.setStock(selectedPet.getStock() - quantity);
    }

    public static String getOrderStatus(User user, String orderId) throws AuthenticationException {
        if (user != null) {
            for (Order o : user.getOrders()) {
                if (o.getOrderId().toString().equals(orderId)) {
                    return o.getStatus();
                }
            }
            return "Order not found";
        } else {
            throw new AuthenticationException("Please login first");
        }
    }

    public static void updateOrderStatus(List<Order> orders, String orderId, String status) throws AuthorizationException {
        boolean orderFound = false;
        for (Order o : orders) {
            if (o.getOrderId().toString().equals(orderId)) {
                o.setStatus(status);
                orderFound = true;
                break;
            }
        }
        if (!orderFound) {
            throw new AuthorizationException("Order not found");
        }
    }

    public static void displayAllOrders(User user) throws AuthenticationException {
        if (user != null) {
            List<Order> orders = user.getOrders();
            if (!orders.isEmpty()) {
                System.out.println("Displaying your orders -\n");
                for (Order o : orders) {
                    System.out.println(o);
                }
            } else {
                System.out.println("Sorry, you have no orders at the moment");
            }
        } else {
            throw new AuthenticationException("Please login first");
        }
    }
}
