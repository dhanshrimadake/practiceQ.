package org.example.utils;

import org.example.entities.User;

import java.util.ArrayList;
import java.util.List;

public final class PopulateUtil {

    private PopulateUtil() {
        // Prevent instantiation
    }

    public static List<User> initialUsers() {
        List<User> list = new ArrayList<>();
        list.add(new User("admin@gmail.com", "admin", "ADMIN"));
        list.add(new User("c1@gmail.com", "1234", "CUSTOMER"));
        return list;
    }
}
