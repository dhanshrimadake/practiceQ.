package org.example.tester;

import org.example.entities.*;
import org.example.exceptions.AuthorizationException;
import org.example.exceptions.OutOfStockException;
import org.example.utils.*;

import java.util.*;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);
    private static List<Pet> pets = new ArrayList<>();
    private static List<User> users = new ArrayList<>();
    private static User currentUser;

    public static void main(String[] args) {
        // Pre-populate some example pets and users
        pets.add(new Pet("Chilu", "Cat", 1000, 10));
        pets.add(new Pet("Dolly", "Dog", 2000, 20));
        users.add(new User("admin@gmail.com", "admin", "ADMIN"));
        users.add(new User("c1@gmail.com", "1234", "CUSTOMER"));

        boolean exit = false;
        while (!exit) {
            System.out.println("1. Login");
            System.out.println("2. Add new pet");
            System.out.println("3. Update pet details");
            System.out.println("4. Display all pets");
            System.out.println("5. Place an order");
            System.out.println("6. Check order status");
            System.out.println("7. Update order status");
            System.out.println("8. Check all your orders");
            System.out.println("9. Exit");

            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    try {
                        login();
                    } catch (org.example.exceptions.AuthenticationException e) {
                        System.out.println("Login failed: " + e.getMessage());
                    }
                    break;
                case 2:
                    addNewPet();
                    break;
                case 3:
                    updatePetDetails();
                    break;
                case 4:
                    try {
                        displayAllPets();
                    } catch (org.example.exceptions.AuthenticationException e) {
                        System.out.println("Display pets failed: " + e.getMessage());
                    }
                    break;
                case 5:
                    try {
                        placeOrder();
                    } catch (org.example.exceptions.AuthenticationException | OutOfStockException e) {
                        System.out.println("Order placement failed: " + e.getMessage());
                    }
                    break;
                case 6:
                    try {
                        checkOrderStatus();
                    } catch (org.example.exceptions.AuthenticationException e) {
                        System.out.println("Check order status failed: " + e.getMessage());
                    }
                    break;
                case 7:
                    updateOrderStatus();
                    break;
                case 8:
                    try {
                        checkAllOrders();
                    } catch (org.example.exceptions.AuthenticationException e) {
                        System.out.println("Check all orders failed: " + e.getMessage());
                    }
                    break;
                case 9:
                    exit = true;
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number from 1 to 9.");
            }
        }
    }

    private static void login() throws org.example.exceptions.AuthenticationException {
        System.out.print("Enter email: ");
        String email = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        currentUser = UserUtil.login(users, email, password);
		System.out.println("Login successful.");
    }

    private static void addNewPet() {
        if (currentUser == null || currentUser.getType() != UserType.ADMIN) {
            System.out.println("Only admins can add new pets.");
            return;
        }

        System.out.print("Enter pet name: ");
        String name = scanner.nextLine();
        System.out.print("Enter category: ");
        String category = scanner.nextLine();
        System.out.print("Enter unit price: ");
        int unitPrice = scanner.nextInt();
        System.out.print("Enter stock: ");
        int stock = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        Pet newPet = new Pet(name, category, unitPrice, stock);
        try {
            UserUtil.addPet(currentUser, pets, newPet);
            System.out.println("New pet added: " + newPet);
        } catch (AuthorizationException e) {
            System.out.println("Authorization failed: " + e.getMessage());
        }
    }

    private static void updatePetDetails() {
        if (currentUser == null || currentUser.getType() != UserType.ADMIN) {
            System.out.println("Only admins can update pet details.");
            return;
        }

        System.out.print("Enter ID of pet to update: ");
        String petId = scanner.nextLine();

        System.out.print("Enter new stock: ");
        int newStock = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            UserUtil.updatePetDetails(currentUser, pets, petId, newStock);
            System.out.println("Pet details updated successfully.");
        } catch (AuthorizationException e) {
            System.out.println("Authorization failed: " + e.getMessage());
        }
    }

    private static void displayAllPets() throws org.example.exceptions.AuthenticationException {
        UserUtil.displayAllPets(currentUser, pets);
    }

    private static void placeOrder() throws org.example.exceptions.AuthenticationException, OutOfStockException {
        if (currentUser == null) {
            System.out.println("Please log in first.");
            return;
        }

        System.out.print("Enter ID of pet: ");
        String petId = scanner.nextLine();
        System.out.print("Enter quantity: ");
        int quantity = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        try {
            UserUtil.orderPet(currentUser, pets, petId, quantity);
            System.out.println("Order placed successfully.");
        } catch (OutOfStockException e) {
            System.out.println("Order placement failed: " + e.getMessage());
        }
    }

    private static void checkOrderStatus() throws org.example.exceptions.AuthenticationException {
        if (currentUser == null) {
            System.out.println("Please log in first.");
            return;
        }

        System.out.print("Enter ID of order: ");
        String orderId = scanner.nextLine();

        String status = UserUtil.getOrderStatus(currentUser, orderId);
		System.out.println("Order status: " + status);
    }

    private static void updateOrderStatus() {
        if (currentUser == null || currentUser.getType() != UserType.ADMIN) {
            System.out.println("Only admins can update order status.");
            return;
        }

        System.out.print("Enter order ID: ");
        String orderId = scanner.nextLine();
        System.out.print("Enter new status: ");
        String newStatus = scanner.nextLine();

        try {
            UserUtil.updateOrderStatus(currentUser.getOrders(), orderId, newStatus);
            System.out.println("Order status updated successfully.");
        } catch (AuthorizationException e) {
            System.out.println("Authorization failed: " + e.getMessage());
        }
    }

    private static void checkAllOrders() throws org.example.exceptions.AuthenticationException {
        UserUtil.displayAllOrders(currentUser);
    }
}
