package org.example.entities;

import java.util.UUID;

public class Pet {
    private UUID petId;
    private String name;
    private PetType category;
    private int unitPrice;
    private int stock;

    public Pet(String name, String category, int unitPrice, int stock) {
        this.petId = UUID.randomUUID();
        this.name = name;
        this.category = PetType.valueOf(category.toUpperCase());
        this.unitPrice = unitPrice;
        this.stock = stock;
    }

    public UUID getPetId() {
        return petId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public PetType getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = PetType.valueOf(category.toUpperCase());
    }

    public int getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(int unitPrice) {
        this.unitPrice = unitPrice;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Pet{");
        sb.append("petId=").append(petId);
        sb.append(", name='").append(name).append('\'');
        sb.append(", category=").append(category);
        sb.append(", unitPrice=").append(unitPrice);
        sb.append(", stocks=").append(stock);
        sb.append('}');
        return sb.toString();
    }
}
