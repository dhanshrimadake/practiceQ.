package org.example.entities;

public enum OrderStatus {
    PLACED,IN_PROCESS,COMPLETED;
}
