package org.example.entities;

public enum PetType {
    CAT,DOG,RABBIT,FISH,OTHER;
}
