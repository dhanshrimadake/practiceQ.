package org.example.entities;

public enum UserType {
    ADMIN,CUSTOMER;
}
