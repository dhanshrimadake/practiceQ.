package org.example.entities;

import java.util.UUID;

public class Order {
    private UUID orderId;
    private User user;
    private Pet pet;
    private int quantity;
    private String status;

    public Order(User currentUser, Pet pet2, int quantity2) {
        this.orderId = UUID.randomUUID();
        this.user = currentUser;
        this.pet = pet2;
        this.quantity = quantity2;
        this.status = "Pending"; // Initial status
    }

    public UUID getOrderId() {
        return orderId;
    }

    public User getUser() {
        return user;
    }

    public Pet getPet() {
        return pet;
    }

    public int getQuantity() {
        return quantity;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        final StringBuffer sb = new StringBuffer("Order{");
        sb.append("orderId=").append(orderId);
//        sb.append(", user=").append(user.getEmail());
//        sb.append(", pet=").append(pet.getName());
        sb.append(", quantity=").append(quantity);
        sb.append(", status='").append(status).append('\'');
        sb.append('}');
        return sb.toString();
    }
}
