package org.example.entities;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String email;
    private String password;
    private UserType type;
    private List<Order> orders;

    public User(String email, String password, String type) {
        this.email = email;
        this.password = password;
        this.type = UserType.valueOf(type.toUpperCase());
        this.orders = new ArrayList<>();
    }

    public void addOrder(Order order) {
        this.orders.add(order);
    }

    public List<Order> getOrders() {
        return orders;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public UserType getType() {
        return type;
    }

    public void setType(String type) {
        this.type = UserType.valueOf(type.toUpperCase());
    }
}
